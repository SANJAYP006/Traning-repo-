import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Hospital {
    private String name;
    private String address;
    private String contactNumber;
    private Map<String, Doctor> doctors;
    private Map<String, Patient> patients;
    private Map<String, Appointment> appointments;
    private int patientCounter;
    private int doctorCounter;
    private int appointmentCounter;

    public Hospital(String name, String address, String contactNumber) {
        this.name = name;
        this.address = address;
        this.contactNumber = contactNumber;
        this.doctors = new HashMap<>();
        this.patients = new HashMap<>();
        this.appointments = new HashMap<>();
        this.patientCounter = 1;
        this.doctorCounter = 1;
        this.appointmentCounter = 1;
    }

    public String addPatient(String name, int age, String gender, String contactNumber, String address) {
        String patientId = "P" + String.format("%04d", patientCounter++);
        Patient newPatient = new Patient(patientId, name, age, gender, contactNumber, address);
        patients.put(patientId, newPatient);
        return patientId;
    }

    public Patient getPatient(String patientId) {
        return patients.get(patientId);
    }

    public List<Patient> getAllPatients() {
        return new ArrayList<>(patients.values());
    }

    public String addDoctor(String name, String specialization, String contactNumber, String email) {
        String doctorId = "D" + String.format("%03d", doctorCounter++);
        Doctor newDoctor = new Doctor(doctorId, name, specialization, contactNumber, email);
        doctors.put(doctorId, newDoctor);
        return doctorId;
    }

    public Doctor getDoctor(String doctorId) {
        return doctors.get(doctorId);
    }

    public List<Doctor> getAllDoctors() {
        return new ArrayList<>(doctors.values());
    }

    public String scheduleAppointment(String patientId, String doctorId, LocalDateTime dateTime) {
        if (!patients.containsKey(patientId) || !doctors.containsKey(doctorId)) {
            return null;
        }
        String appointmentId = "A" + String.format("%05d", appointmentCounter++);
        Appointment newAppointment = new Appointment(
            appointmentId,
            patients.get(patientId),
            doctors.get(doctorId),
            dateTime
        );
        appointments.put(appointmentId, newAppointment);
        return appointmentId;
    }

    public boolean cancelAppointment(String appointmentId) {
        if (appointments.containsKey(appointmentId)) {
            appointments.get(appointmentId).cancelAppointment();
            return true;
        }
        return false;
    }

    public List<Appointment> getDoctorAppointments(String doctorId) {
        List<Appointment> doctorAppointments = new ArrayList<>();
        for (Appointment appointment : appointments.values()) {
            if (appointment.getDoctor().getDoctorId().equals(doctorId)) {
                doctorAppointments.add(appointment);
            }
        }
        return doctorAppointments;
    }

    public List<Appointment> getPatientAppointments(String patientId) {
        List<Appointment> patientAppointments = new ArrayList<>();
        for (Appointment appointment : appointments.values()) {
            if (appointment.getPatient().getPatientId().equals(patientId)) {
                patientAppointments.add(appointment);
            }
        }
        return patientAppointments;
    }

    
    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getContactNumber() {
        return contactNumber;
    }
}
