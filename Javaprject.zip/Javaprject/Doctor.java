public class Doctor {
    private String doctorId;
    private String name;
    private String specialization;
    private String contactNumber;
    private String email;

    public Doctor(String doctorId, String name, String specialization, String contactNumber, String email) {
        this.doctorId = doctorId;
        this.name = name;
        this.specialization = specialization;
        this.contactNumber = contactNumber;
        this.email = email;
    }

    public String getDoctorId() {
        return doctorId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
  
    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "Doctor ID: " + doctorId + "\n" +
               "Name: Dr. " + name + "\n" +
               "Specialization: " + specialization + "\n" +
               "Contact: " + contactNumber + "\n" +
               "Email: " + email;
    }
}
