import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static Hospital hospital;
    private static Scanner scanner = new Scanner(System.in);
    private static DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public static void main(String[] args) {
        initializeHospital();
        showMainMenu();
    }

    private static void initializeHospital() {
        hospital = new Hospital("City General Hospital", "Medical Center Drive, City", "+91 7142344567");
        
        hospital.addDoctor("Sanjay Shetty", "Cardiology", "+91 9918127222", "Sanjay@hospital.com");
        hospital.addDoctor("Amruth Narayan", "Neurology", "+91 7227238333", "Amruth@hospital.com");
        hospital.addDoctor("Nishanth Shadli", "Pediatrics", "+91  8933394444", "Nisahntha@hospital.com");
    }

    private static void showMainMenu() {
        while (true) {
            System.out.println("\n=== " + hospital.getName() + " ===");
            System.out.println("1. Patient Management");
            System.out.println("2. Doctor Management");
            System.out.println("3. Appointment Management");
            System.out.println("4. Exit");
            System.out.print("Select an option: ");

            int choice = getIntInput(1, 4);

            switch (choice) {
                case 1:
                    showPatientMenu();
                    break;
                case 2:
                    showDoctorMenu();
                    break;
                case 3:
                    showAppointmentMenu();
                    break;
                case 4:
                    System.out.println("Thank you for using the Hospital Management System. Goodbye!");
                    return;
            }
        }
    }

    private static void showPatientMenu() {
        while (true) {
            System.out.println("\n=== Patient Management ===");
            System.out.println("1. Register New Patient");
            System.out.println("2. View All Patients");
            System.out.println("3. Back to Main Menu");
            System.out.print("Select an option: ");

            int choice = getIntInput(1, 3);

            switch (choice) {
                case 1:
                    registerPatient();
                    break;
                case 2:
                    viewAllPatients();
                    break;
                case 3:
                    return;
            }
        }
    }

    private static void showDoctorMenu() {
        while (true) {
            System.out.println("\n=== Doctor Management ===");
            System.out.println("1. View All Doctors");
            System.out.println("2. View Doctor Schedule");
            System.out.println("3. Back to Main Menu");
            System.out.print("Select an option: ");

            int choice = getIntInput(1, 3);

            switch (choice) {
                case 1:
                    viewAllDoctors();
                    break;
                case 2:
                    viewDoctorSchedule();
                    break;
                case 3:
                    return;
            }
        }
    }

    private static void showAppointmentMenu() {
        while (true) {
            System.out.println("\n=== Appointment Management ===");
            System.out.println("1. Schedule New Appointment");
            System.out.println("2. Cancel Appointment");
            System.out.println("3. View Patient Appointments");
            System.out.println("4. Back to Main Menu");
            System.out.print("Select an option: ");

            int choice = getIntInput(1, 4);

            switch (choice) {
                case 1:
                    scheduleAppointment();
                    break;
                case 2:
                    cancelAppointment();
                    break;
                case 3:
                    viewPatientAppointments();
                    break;
                case 4:
                    return;
            }
        }
    }

    private static void registerPatient() {
        System.out.println("\n=== Register New Patient ===");
        System.out.print("Enter patient name: ");
        String name = scanner.nextLine();
        
        System.out.print("Enter age: ");
        int age = getIntInput(0, 120);
        
        System.out.print("Enter gender (M/F/Other): ");
        String gender = scanner.nextLine();
        
        System.out.print("Enter contact number: ");
        String contactNumber = scanner.nextLine();
        
        System.out.print("Enter address: ");
        String address = scanner.nextLine();
        
        String patientId = hospital.addPatient(name, age, gender, contactNumber, address);
        System.out.println("\nPatient registered successfully!");
        System.out.println("Patient ID: " + patientId);
    }

    private static void viewAllPatients() {
        System.out.println("\n=== All Patients ===");
        List<Patient> patients = hospital.getAllPatients();
        if (patients.isEmpty()) {
            System.out.println("No patients found.");
            return;
        }
        
        for (Patient patient : patients) {
            System.out.println("\n" + patient);
            System.out.println("--------------------");
        }
    }

    private static void viewAllDoctors() {
        System.out.println("\n=== All Doctors ===");
        List<Doctor> doctors = hospital.getAllDoctors();
        if (doctors.isEmpty()) {
            System.out.println("No doctors found.");
            return;
        }
        
        for (Doctor doctor : doctors) {
            System.out.println("\n" + doctor);
            System.out.println("--------------------");
        }
    }

    private static void viewDoctorSchedule() {
        System.out.println("\n=== Doctor Schedule ===");
        List<Doctor> doctors = hospital.getAllDoctors();
        if (doctors.isEmpty()) {
            System.out.println("No doctors available.");
            return;
        }
        
        System.out.println("\nSelect a doctor:");
        for (int i = 0; i < doctors.size(); i++) {
            System.out.printf("%d. %s (%s)\n", i + 1, doctors.get(i).getName(), doctors.get(i).getSpecialization());
        }
        
        System.out.print("Enter doctor number: ");
        int choice = getIntInput(1, doctors.size());
        Doctor doctor = doctors.get(choice - 1);
        
        List<Appointment> appointments = hospital.getDoctorAppointments(doctor.getDoctorId());
        System.out.println("\nAppointments for Dr. " + doctor.getName() + ":");
        
        if (appointments.isEmpty()) {
            System.out.println("No appointments found.");
            return;
        }
        
        for (Appointment appointment : appointments) {
            System.out.println("\n" + appointment);
            System.out.println("--------------------");
        }
    }

    private static void scheduleAppointment() {
        System.out.println("\n=== Schedule New Appointment ===");
        
        System.out.print("Enter patient ID (or leave empty to view all patients): ");
        String patientId = scanner.nextLine();
        
        if (patientId.isEmpty()) {
            viewAllPatients();
            System.out.print("\nEnter patient ID: ");
            patientId = scanner.nextLine();
        }
        
        Patient patient = hospital.getPatient(patientId);
        if (patient == null) {
            System.out.println("Patient not found!");
            return;
        }
        
        List<Doctor> doctors = hospital.getAllDoctors();
        System.out.println("\nSelect a doctor:");
        for (int i = 0; i < doctors.size(); i++) {
            System.out.printf("%d. %s (%s)\n", i + 1, 
                doctors.get(i).getName(), 
                doctors.get(i).getSpecialization());
        }
        
        System.out.print("Enter doctor number: ");
        int doctorChoice = getIntInput(1, doctors.size());
        Doctor doctor = doctors.get(doctorChoice - 1);
        
        LocalDateTime dateTime = null;
        while (dateTime == null) {
            try {
                System.out.print("Enter appointment date and time (yyyy-MM-dd HH:mm): ");
                String dateTimeStr = scanner.nextLine();
                dateTime = LocalDateTime.parse(dateTimeStr, dateTimeFormatter);
                
                if (dateTime.isBefore(LocalDateTime.now())) {
                    System.out.println("Cannot schedule an appointment in the past!");
                    dateTime = null;
                }
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date/time format. Please use yyyy-MM-dd HH:mm");
            }
        }
        
        String appointmentId = hospital.scheduleAppointment(
            patient.getPatientId(), 
            doctor.getDoctorId(), 
            dateTime
        );
        
        if (appointmentId != null) {
            System.out.println("\nAppointment scheduled successfully!");
            System.out.println("Appointment ID: " + appointmentId);
        } else {
            System.out.println("\nFailed to schedule appointment. Please check the patient and doctor IDs.");
        }
    }

    private static void cancelAppointment() {
        System.out.println("\n=== Cancel Appointment ===");
        System.out.print("Enter appointment ID to cancel: ");
        String appointmentId = scanner.nextLine();
        
        if (hospital.cancelAppointment(appointmentId)) {
            System.out.println("Appointment cancelled successfully!");
        } else {
            System.out.println("Appointment not found or already cancelled!");
        }
    }

    private static void viewPatientAppointments() {
        System.out.println("\n=== View Patient Appointments ===");
        System.out.print("Enter patient ID: ");
        String patientId = scanner.nextLine();
        
        List<Appointment> appointments = hospital.getPatientAppointments(patientId);
        if (appointments.isEmpty()) {
            System.out.println("No appointments found for this patient.");
            return;
        }
        
        System.out.println("\nAppointments for " + hospital.getPatient(patientId).getName() + ":");
        for (Appointment appointment : appointments) {
            System.out.println("\n" + appointment);
            System.out.println("--------------------");
        }
    }

    private static int getIntInput(int min, int max) {
        while (true) {
            try {
                int input = Integer.parseInt(scanner.nextLine());
                if (input >= min && input <= max) {
                    return input;
                }
                System.out.printf("Please enter a number between %d and %d: ", min, max);
            } catch (NumberFormatException e) {
                System.out.printf("Invalid input. Please enter a number between %d and %d: ", min, max);
            }
        }
    }
}
