import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Appointment {
    private String appointmentId;
    private Patient patient;
    private Doctor doctor;
    private LocalDateTime appointmentDateTime;
    private String status; 

    public Appointment(String appointmentId, Patient patient, Doctor doctor, LocalDateTime appointmentDateTime) {
        this.appointmentId = appointmentId;
        this.patient = patient;
        this.doctor = doctor;
        this.appointmentDateTime = appointmentDateTime;
        this.status = "Scheduled";
    }

    public String getAppointmentId() {
        return appointmentId;
    }

    public Patient getPatient() {
        return patient;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public LocalDateTime getAppointmentDateTime() {
        return appointmentDateTime;
    }

    public void setAppointmentDateTime(LocalDateTime appointmentDateTime) {
        this.appointmentDateTime = appointmentDateTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void cancelAppointment() {
        this.status = "Cancelled";
    }

    public void completeAppointment() {
        this.status = "Completed";
    }

    @Override
    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        return "Appointment ID: " + appointmentId + "\n" +
               "Patient: " + patient.getName() + " (ID: " + patient.getPatientId() + ")\n" +
               "Doctor: Dr. " + doctor.getName() + " (" + doctor.getSpecialization() + ")\n" +
               "Date & Time: " + appointmentDateTime.format(formatter) + "\n" +
               "Status: " + status;
    }
}
